<?php

$servername = "localhost";
$username = "excusevi_Main";
$password = "excusevi_Main";
$dbname = "excusevi_Main";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>